<?php die() ?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Signin | Cabrera Feeds Supply</title>
    <link rel="icon" type="image/png" href="<?php echo base_url('assets/images/1.ico') ?>">
   <!--  <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet"> -->
    <link href="<?php echo base_url('assets/css/themes/lite-purple.min.css') ?>" rel="stylesheet">
</head>
<!-- <div class="auth-layout-wrap" style="background-image: url('<?php echo base_url('assets/images/pin.jpg') ?>')"> -->
<div class="auth-layout-wrap" id="content">
    <div class="auth-content">
        <div class="card o-hidden">

            <div class="row">
                <div class="col-md-12">
                    <div class="p-4">
                        <form  method="POST" action="<?php echo base_url(); ?>index.php/Pages/validate_login">
                        <div class="auth-logo text-center mb-2">
                            <span style=" font-family: 'Raleway',sans-serif;font-weight: 800; font-size:35px; line-height: 72px; margin: 0 0 24px; text-align: center; text-transform: uppercase; ">CABRERA</span><span style=" font-family: 'Open Sans', sans-serif; font-size: 13px; line-height: 28px; margin: 0 0 48px;"> FEEDS SUPPLY</span>

                        </div>
                        <h2 class="mb-3 text-15">Sign In</h2>
                        
                            <div class="form-group">
                                <label for="email text-15" style="font-size: 14px;">Username</label>
                                <input class="form-control form-control-rounded" name="user_name" id="user_name"  type="text">
                            </div>
                            <div class="form-group">
                                <label for="password" style="font-size: 14px;">Password</label>
                                <input class="form-control form-control-rounded" name="user_pass" id="user_pass" type="password">
                            </div>
                            
                            <button type="submit"  class="btn btn-rounded btn-warning btn-block mt-2 btn-lg" style ='color:#eee'>Sign In</button>
                        </form>

                        <?php
                            if($this->session->flashdata('error')){
                                ?>
                                <div class="alert alert-danger text-center" style="margin-top:15px; margin-bottom: -10px;">
                                    <?php echo $this->session->flashdata('error'); ?>
                                </div>
                                <?php
                            }
                        ?>
                    </div>
                     <br/>
                </div>

            </div>
        </div>
    </div>
</div>

<style type="text/css">
    .auth-layout-wrap .auth-content {
    min-width: 400px !important;
}

#content{
    background:url('<?php echo base_url('assets/images/bodyBg.png') ?>') repeat #fff;
    margin-left:0px;
    margin-right: 0;
    /*margin-top:80px;*/
  /*  margin-top:38px;*/
    padding-bottom: 25px;
    position: relative;
    /*min-height: 500px;*/
    width: auto;
}
</style>