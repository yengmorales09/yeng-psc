<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2"><?php echo $title; ?></h1>
        <ul>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/create_so')?>">Create Order</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/list_so')?>">Order List</a></li>
        </ul>
    </div>

     <div class="separator-breadcrumb border-top"></div>
    
        <div class="col-md-11">
            <div class="card">
                <div class="card-body">
                    <br/>
                    <div class="col-md-12">
                        <div class="row row-xs">
                            <div class="col-md-3">
                                <select class="form-control">
                                  <option value="" selected="" disabled="">Select Report Type</option>
                                  <option>Sales Order Summary</option>
                                  <option>Orders Per Status</option>
                                  <option>Orders Per Customer</option>
                                </select>
                            </div>
                            <div class="col-md-2 mt-3 mt-md-0">
                                <input class="form-control" type="password" placeholder="Date From">
                            </div>
                            <div class="col-md-2 mt-3 mt-md-0">
                                <input class="form-control" type="password" placeholder="Date From">
                            </div>
                            <div class="col-md-5 mt-3 mt-md-0">
                                <button style="float:right" class="btn btn-success btn-icon btn-sm" type="submit">
                                    <span style="font-size:15px;" class="ul-btn__icon"><i class="i-File-Excel"></i></span>
                                    <span style="font-size:15px;" class="ul-btn__text">Export</span></button>

                                <button style="float:right; margin-right:10px;" class="btn btn-info btn-icon btn-sm" type="submit">
                                    <span style="font-size:15px;" class="ul-btn__icon"><i class="i-Share"></i></span>
                                    <span style="font-size:15px;" class="ul-btn__text">Run</span></button>
                                
                            </div>
                        </div>
                    </div>

                    <br/><br/>
                    <div class="col-md-12">
                        <h5 class="card-title mb-3">Sales Order Summary From 01/02/2021 - 01/31/2021</h5>
                         <div class="table-responsive">
                            <table class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th scope="col" class="text-center" style="width:50px">#</th>
                                        <th scope="col" class="text-center" style="width:150px">Order No</th>
                                        <th scope="col" class="text-center" style="width:150px">Order Date</th>
                                        <th scope="col" class="text-center">Customer</th>
                                        <th scope="col" class="text-center" style="width:150px">QTY</th>
                                        <th scope="col" class="text-center" style="width:150px">Amount</th>
                                        <th scope="col" class="text-center" style="width:150px">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th class="text-center">1</th>
                                        <td class="text-center">00001</td>
                                        <td class="text-center">12-10-2019</td>
                                        <td>Sample Customer Name</td>
                                        <td class="text-center">7</td>
                                        <td class="text-center">P50,000.00</td>
                                        <td class="text-center">Pending</td>
                                    </tr>
                                    <tr>
                                        <th class="text-center">2</th>
                                        <td class="text-center">00001</td>
                                        <td class="text-center">12-10-2019</td>
                                        <td>Sample Customer Name</td>
                                        <td class="text-center">6</td>
                                        <td class="text-center">P50,000.00</td>
                                        <td class="text-center">Closed</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <br/><br/>
                    <div class="col-md-8">
                        <h5 class="card-title mb-3">Sales Order Status Summary From 01/02/2021 - 01/31/2021</h5>
                         <div class="table-responsive">
                            <table class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th scope="col" class="text-center" style="width:50px">#</th>
                                        <th scope="col" class="text-center" style="width:150px">Status</th>
                                        <th scope="col" class="text-center" style="width:150px">Total Orders</th>
                                        <th scope="col" class="text-center" style="width:150px">Total QTY</th>
                                        <th scope="col" class="text-center" style="width:150px">Total Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th class="text-center">1</th>
                                        <td class="text-center">Pending</td>
                                        <td class="text-center">12</td>
                                        <td class="text-center">150</td>
                                        <td class="text-center">P120,000</td>
                                    </tr>
                                    <tr>
                                        <th class="text-center">1</th>
                                        <td class="text-center">Closed</td>
                                        <td class="text-center">12</td>
                                        <td class="text-center">150</td>
                                        <td class="text-center">P120,000</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <br/><br/>
                    <div class="col-md-12">
                        <h5 class="card-title mb-3">Customer Order Summary From 01/02/2021 - 01/31/2021</h5>
                         <div class="table-responsive">
                            <table class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th scope="col" class="text-center" style="width:50px">#</th>
                                        <th scope="col" class="text-center" style="width:350px">Customer</th>
                                        <th scope="col" class="text-center" style="width:150px">Total Orders</th>
                                        <th scope="col" class="text-center" style="width:150px">Total QTY</th>
                                        <th scope="col" class="text-center" style="width:150px">Total Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th class="text-center">1</th>
                                        <td>Sample Customer Name</td>
                                        <td class="text-center">12</td>
                                        <td class="text-center">150</td>
                                        <td class="text-center">P120,000</td>
                                    </tr>
                                    <tr>
                                        <th class="text-center">1</th>
                                        <td>Sample Customer Name</td>
                                        <td class="text-center">12</td>
                                        <td class="text-center">150</td>
                                        <td class="text-center">P120,000</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
</div>

<style type="text/css">
    select, select.form-control {
 
  background          : url('assets/images/caret-for-select.png');
  background-position : 100% 50% !important;
  background-repeat   : no-repeat !important;
  background-size     : auto 15% !important;

}
</style>

