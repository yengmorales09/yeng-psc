        <div class="main-header">
            <!-- <div class="logo">
                <img style="height:29px !important;width:400px !important" src="<?php echo base_url('assets/images/cabs2.png') ?>" alt="">
            </div> -->
            <div class="menu-toggle" hidden="">
                <div></div>
                <div></div>
                <div></div>
            </div>
            <div class="d-flex align-items-center">
                <!-- Mega menu -->
                <div class="dropdown mega-menu d-none d-md-block" style="padding-left: 20px;">
                    <span style=" font-family: 'Raleway',sans-serif;font-weight: 800; font-size:35px; line-height: 72px; margin: 0 0 24px; text-align: center; text-transform: uppercase; ">CABRERA</span><span style=" font-family: 'Open Sans', sans-serif; font-size: 13px; line-height: 28px; margin: 0 0 48px;"> FEEDS SUPPLY</span>
                    
                </div>
                <!-- / Mega menu -->
            </div>
            <div style="margin: auto"></div>
            <div class="header-part-right">
                <!-- User avatar dropdown -->
                <div class="dropdown">
                    <div class="user col align-self-end">
                        <img src="<?php echo base_url('assets/images/faces/user-prof.png') ?>" id="userDropdown" alt="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                            <div class="dropdown-header" style="font-size:15px;">
                                <i class="i-Lock-User mr-1"></i> <?php echo $this->session->userdata('user_fullname') ?>
                            </div>
                            <a href="<?php echo base_url('/change_pass') ?>" class="dropdown-item" style="font-size:14px;">Change Password</a>
                            <a href="<?php echo base_url('/logout') ?>" class="dropdown-item" style="font-size:14px;">Sign out</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>