<?php
$po ='';
$so ='';
$pm ='';
$in ='';
$re ='';
$fm ='';

if ($page == 'purchase') {
    $po = "active";
}else if($page == 'order'){
    $so = 'active';
}else if($page == 'delivery'){
    $dr = 'active';
}else if($page == 'inventory'){
    $in = 'active';
}else if($page == 'iwe'){
    $iwe = 'active';
}else if($page == 'file_mgmt'){
    $fm = 'active';
}else{
   $po ='';
    $so ='';
    $pm ='';
    $in ='';
    $re ='';
    $fm ='';
}
?>


<div class="side-content-wrap">
    
    <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar="" data-suppress-scroll-x="true">
        <ul class="navigation-left">
            <li class="nav-item <?php echo $po; ?>"><a class="nav-item-hold" href="<?= base_url('/create_po') ?>"><i class="nav-icon i-Receipt-3"></i><span class="nav-text">Purchases</span></a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item <?php echo $so; ?>"><a class="nav-item-hold" href="<?= base_url('/create_so') ?>"><i class="nav-icon i-Cash-Register"></i><span class="nav-text">Sales</span></a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item <?php echo $pm; ?>"><a class="nav-item-hold" href="<?= base_url('/create_so') ?>"><i class="nav-icon i-Cash-register-2"></i><span class="nav-text">Payments</span></a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item <?php echo $in; ?>"><a class="nav-item-hold" href="<?= base_url('/invty_list') ?>"><i class="nav-icon i-Box-Full"></i><span class="nav-text">Inventory</span></a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item <?php echo $re; ?>"><a class="nav-item-hold" href="<?= base_url('/invty_list') ?>"><i class="nav-icon i-Bar-Chart-4"></i><span class="nav-text">Reports</span></a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item <?php echo $fm; ?>"><a class="nav-item-hold" href="<?= base_url('/branch_fm') ?>"><i class="nav-icon i-Gears"></i><span class="nav-text">File Management</span></a>
                <div class="triangle"></div>
            </li>
        </ul>
    </div>
 
    <div class="sidebar-overlay"></div>
</div>
<div class="main-content-wrap sidenav-open d-flex flex-column">