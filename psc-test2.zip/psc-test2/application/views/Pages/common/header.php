<!DOCTYPE html>
<html lang="en" dir="">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>CABRERA FEEDS SUPPLY</title>
    <link href="<?php echo base_url('assets/css/themes/lite-purple.min.css') ?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/css/plugins/perfect-scrollbar.min.css') ?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/css/plugins/datatables.min.css') ?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/css/plugins/sweetalert.css') ?>" rel="stylesheet" />
    <link rel="icon" type="image/png" href="<?php echo base_url('assets/images/1.ico') ?>">
    <script src="<?php echo base_url('assets/js/plugins/jquery-3.3.1.min.js') ?>" type = "text/javascript"></script>
    <script src="<?php echo base_url('assets/js/plugins/sweetalert.js') ?>"></script>
    <!-- <script src="<?php echo base_url()?>assets/js/scripts/bootstrap-datepicker.js"></script> -->
    <script src="<?php echo base_url()?>assets/js/scripts/jquery-ui.js"></script>
    <!-- <script src="<?php echo base_url('assets/js/plugins/jquery.min.js') ?>" type = "text/javascript"></script> -->
</head>

<body class="text-left">
	<div class="app-admin-wrap layout-sidebar-large">