<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2"><?php echo $title; ?></h1>
        <ul>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/branch_fm')?>">Branch</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/brands_fm')?>">Brands</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/cust_fm')?>">Customers</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/users_fm')?>">Users</a></li>
        </ul>
    </div>

     <div class="separator-breadcrumb border-top"></div>
     <br/>
        <div class="col-md-11">
            <div class="card">
                <div class="card-body">
                    <br/>
                     <div class="col-md-12">
                        <div class="row row-xs">
                            <div class="col-md-12 mt-3 mt-md-0">
                               <div class="col-md-1 offset-md-11">
                                    <button style="float:right; padding-top:1px; padding-bottom:1px; font-size: 10px;" class="btn btn-success btn-icon btn-sm" data-toggle="modal" data-target=".mod_add" type="button">
                                    <span style="font-size:15px;" class="ul-btn__icon"><i class="i-Add"></i></span>
                                    <span style="font-size:12px;" class="ul-btn__text">Add New</span></button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <br/>
                     <div class="table-responsive">
                        <table class="display table table-striped table-bordered table-sm" id="deafult_ordering_table" style="width:100%">
                            <thead>
                                <tr>
                                    <th class="text-center" style="width:8px;">#</th>
                                    <th class="text-center" style="width:85px;">Brand</th>
                                    <th class="text-center">Item Name</th>
                                    <th class="text-center" style="width:100px;">Retail Price</th>
                                    <th class="text-center" style="width:120px;">Wholesale Price</th>
                                    <th class="text-center" style="width:100px;">Container Price</th>
                                    <th class="text-center" style="width:50px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="text-center">1</td>
                                    <td class="text-center">Tank Top</td>
                                    <td>Mixed Shorts</td>
                                    <td class="text-center">5,000</td>
                                    <td class="text-center">5,000</td>
                                    <td class="text-center">5,000</td>
                                    <td class="text-center">
                                            <button type="button" data-toggle="modal" data-target=".mod_edit" style="margin-top:3px;" class="btn btn-success btn-sm" type="button"><i class="nav-icon i-Pen-2"></i></button>
                                            <button data-toggle="modal" data-target=".mod_del" style="margin-top:3px;" class="btn btn-danger btn-sm" type="button"><i class="nav-icon i-Close-Window"></i></button>
                                        </td>
                                </tr>
                               
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</div>

<div class="modal fade bd-example-modal-lg mod_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Edit Item</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <div class="modal-body" style="padding-left:40px; padding-top:40px;">
                   <div class="form-group row">
                                <div class="col-sm-12">
                                    <div class="form-group row cstmmargintop">
                                    <label class="col-sm-3 col-form-label" for="inputEmail3">Brand</label>
                                       <div class="col-md-6">
                                            <select class="form-control" required="required" type="text">
                                              <option></option>
                                              <option>Brand 1</option>
                                              <option>Brand 1</option>
                                              <option>Brand 1</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row cstmmargintop">
                                    <label class="col-sm-3 col-form-label" for="inputEmail3">Item Name</label>
                                        <div class="col-sm-8">
                                            <input class="form-control" required="required" type="text" id="2">
                                        </div>
                                    </div>
                                    <div class="form-group row cstmmargintop">
                                    <label class="col-sm-3 col-form-label" for="inputEmail3">Retail Price</label>
                                         <div class="col-sm-3">
                                            <input class="form-control" required="required" type="text" id="2">
                                        </div>
                                    </div>
                                    <div class="form-group row cstmmargintop">
                                    <label class="col-sm-3 col-form-label" for="inputEmail3">Container Price</label>
                                         <div class="col-sm-3">
                                            <input class="form-control" required="required" type="text" id="2">
                                        </div>
                                    </div>
                                    <div class="form-group row cstmmargintop">
                                    <label class="col-sm-3 col-form-label" for="inputEmail3">Wholesale Price</label>
                                         <div class="col-sm-3">
                                            <input class="form-control" required="required" type="text" id="2">
                                        </div>
                                    </div>
                                </div>

                            </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success ml-2 btn-sm" type="button">Update Item</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bd-example-modal-lg mod_add" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Add Item</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <div class="modal-body" style="padding-left:40px; padding-top:40px;">
                   <div class="form-group row">
                                <div class="col-sm-12">
                                    <div class="form-group row cstmmargintop">
                                    <label class="col-sm-3 col-form-label" for="inputEmail3">Brand</label>
                                       <div class="col-md-6">
                                            <select class="form-control" required="required" type="text">
                                              <option></option>
                                              <option>Brand 1</option>
                                              <option>Brand 1</option>
                                              <option>Brand 1</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row cstmmargintop">
                                    <label class="col-sm-3 col-form-label" for="inputEmail3">Item Name</label>
                                        <div class="col-sm-8">
                                            <input class="form-control" required="required" type="text" id="2">
                                        </div>
                                    </div>
                                    <div class="form-group row cstmmargintop">
                                    <label class="col-sm-3 col-form-label" for="inputEmail3">Retail Price</label>
                                         <div class="col-sm-3">
                                            <input class="form-control" required="required" type="text" id="2">
                                        </div>
                                    </div>
                                    <div class="form-group row cstmmargintop">
                                    <label class="col-sm-3 col-form-label" for="inputEmail3">Container Price</label>
                                         <div class="col-sm-3">
                                            <input class="form-control" required="required" type="text" id="2">
                                        </div>
                                    </div>
                                    <div class="form-group row cstmmargintop">
                                    <label class="col-sm-3 col-form-label" for="inputEmail3">Wholesale Price</label>
                                         <div class="col-sm-3">
                                            <input class="form-control" required="required" type="text" id="2">
                                        </div>
                                    </div>
                                </div>

                            </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success ml-2 btn-sm" type="button">Save New Item</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bd-example-modal-sm mod_del" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Delete Branch</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body" style="padding:10px;">
                <br/>
               <div class="form-group row">
                    <div class="col-sm-12">
                        <label class="col-sm-12 col-form-label" for="inputEmail3">Are you sure you want to delete Item Name ?.</label>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
                <button class="btn btn-danger ml-2" type="button">YES</button>
            </div>
        </div>
    </div>
</div>

<style type="text/css">
    .btn-secondary:focus, .btn-outline-secondary:focus {
        box-shadow: 0 8px 25px -4px #52495a !important;}

    select, select.form-control {
 
  background          : url('assets/images/caret-for-select.png');
  background-position : 100% 50% !important;
  background-repeat   : no-repeat !important;
  background-size     : auto 15% !important;

}

</style>
