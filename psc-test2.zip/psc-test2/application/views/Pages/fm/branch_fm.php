<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2"><?php echo $title; ?></h1>
        <ul>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/items_fm')?>">Items</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/brands_fm')?>">Brands</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/cust_fm')?>">Customers</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/users_fm')?>">Users</a></li>
        </ul>
    </div>

     <div class="separator-breadcrumb border-top"></div>
     <br/>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <br/>
                    <div class=" form-group row">
                                <div class="col-md-1 offset-md-11">
                                    <button style="float:right; padding-top:1px; padding-bottom:1px; font-size: 10px;" class="btn btn-success btn-icon btn-sm" data-toggle="modal" data-target=".mod_add" type="button">
                                    <span style="font-size:15px;" class="ul-btn__icon"><i class="i-Add"></i></span>
                                    <span style="font-size:12px;" class="ul-btn__text">Add New</span></button>
                                </div>
                            </div>
                    <div class="col-md-12">
                         <div class="table-responsive">
                            <table class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="width:33px;">#</th>
                                        <th class="text-center" style="width:120px;">Branch Type</th>
                                        <th class="text-center">Branch Name</th>
                                        <th class="text-center" style="width:95px;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-center">1</td>
                                        <td class="text-center">Main</td>
                                        <td class="text-center">Main Branch</td>
                                        <td class="text-center">
                                            <button type="button" data-toggle="modal" data-target=".mod_edit" style="margin-top:3px;" class="btn btn-success btn-sm" type="button"><i class="nav-icon i-Pen-2"></i></button>
                                            <button type="button" data-toggle="modal" data-target=".mod_del" style="margin-top:3px;" class="btn btn-danger btn-sm" type="button"><i class="nav-icon i-Close-Window"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">2</td>
                                        <td class="text-center">Sub-Branch</td>
                                        <td class="text-center">Sub Branch</td>
                                        <td class="text-center">
                                            <button style="margin-top:3px;" class="btn btn-success btn-sm" type="button"><i class="nav-icon i-Pen-2"></i></button>
                                            <button style="margin-top:3px;" class="btn btn-danger btn-sm" type="button"><i class="nav-icon i-Close-Window"></i></button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>

<div class="modal fade bd-example-modal-sm mod_add" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Add Branch</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body" style="padding-left:40px;padding-right:40px;">
                <br/>
               <div class="form-group row">
                    <div class="col-sm-12">
                        <div class="form-group row cstmmargintop">
                        <label class="col-sm-4 col-form-label" for="inputEmail3">Branch Type</label>
                           <div class="col-md-8">
                                <select class="form-control" required="required" type="text">
                                  <option></option>
                                  <option>Main Branch</option>
                                  <option>Sub Branch</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row cstmmargintop">
                        <label class="col-sm-4 col-form-label" for="inputEmail3">Branch Name</label>
                            <div class="col-sm-8">
                                <input class="form-control" required="required" type="text" id="2" >
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-success ml-2 btn-sm" type="button">Save New Branch</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bd-example-modal-sm mod_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Edit Branch</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body" style="padding-left:40px;padding-right:40px;">
                <br/>
               <div class="form-group row">
                    <div class="col-sm-12">
                        <div class="form-group row cstmmargintop">
                        <label class="col-sm-4 col-form-label" for="inputEmail3">Branch Type</label>
                           <div class="col-md-8">
                                <select class="form-control" required="required" type="text">
                                  <option selected="">Main Branch</option>
                                  <option>Sub Branch</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row cstmmargintop">
                        <label class="col-sm-4 col-form-label" for="inputEmail3">Branch Name</label>
                            <div class="col-sm-8">
                                <input class="form-control" required="required" type="text" id="2" value="Main Branch">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
                <button class="btn btn-success ml-2" type="button">Save changes</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bd-example-modal-sm mod_del" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Delete Branch</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body" style="padding:10px;">
                <br/>
               <div class="form-group row">
                    <div class="col-sm-12">
                        <label class="col-sm-12 col-form-label" for="inputEmail3">Are you sure you want to delete Branch Name ?.</label>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
                <button class="btn btn-danger ml-2" type="button">YES</button>
            </div>
        </div>
    </div>
</div>

<style type="text/css">
    .btn-secondary:focus, .btn-outline-secondary:focus {
        box-shadow: 0 8px 25px -4px #52495a !important;}

    select, select.form-control {
 
  background          : url('assets/images/caret-for-select.png');
  background-position : 100% 50% !important;
  background-repeat   : no-repeat !important;
  background-size     : auto 15% !important;

}

</style>
