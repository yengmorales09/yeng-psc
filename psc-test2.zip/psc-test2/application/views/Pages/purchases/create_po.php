<?php
foreach ($max_po as $key => $value) {
	$max_po = $value->po_no;
}
$max_po = $max_po + 1; 
?>

<div class="main-content">
    <div class="breadcrumb">
        <h3 class="mr-2" style="padding-top:10px;"><?php echo $title; ?></h3>
        <ul>
            <li ><a style="font-size: 14px; " href="<?php echo base_url('/list_po')?>">Purchase Order List <i style="font-size:10px;" class="i-Arrow-Right-2"></i> <i style="font-size:10px;margin-left:-10px;" class="i-Arrow-Right-2"></i> </a></li>
        </ul>
    </div>

     <div class="separator-breadcrumb border-top"></div>
	    <div class="row">
	        <div class="col-md-12">
	            <div class="card mb-4">
	                <div class="card-body" style="padding-left:30px;padding-right:30px;">
	                    <form class="needs-validation" novalidate="novalidate">
	                    	<div class=" form-group row">
	                    		<div class="col-md-1 offset-md-11">
	                    			<button style="float:right" class="btn btn-info btn-icon btn-sm" type="submit">
		                    		<span style="font-size:15px;" class="ul-btn__icon"><i class="i-Memory-Card-2"></i></span>
		                    		<span style="font-size:15px;" class="ul-btn__text">Save</span></button>
	                    		</div>
	                    	</div>
	                    	<div class="form-group row">
	                    		<div class="col-sm-7">
	                    			<div class="form-group row ">
	                                <label class="col-sm-2 col-form-label" for="inputEmail3">P.O No</label>
		                                <div class="col-sm-3">
		                                    <input class="form-control input-sm" required="required" type="text" disabled="" value="PO-<?php echo $max_po; ?>" >
		                                </div>
		                             <label class="col-sm-2 col-form-label text-right" for="inputEmail3">P.O Date</label>
		                              <div class="col-sm-3">
		                                    <input id="po_date" class="form-control input-sm" value="<?php echo date('m/d/Y') ?>" required="required">
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-2 col-form-label" for="inputEmail3">Supplier</label>
		                                <div class="col-sm-10">
		                                    <input class="form-control" required="required" type="text">
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-2 col-form-label" for="inputEmail3">Address</label>
		                                <div class="col-sm-10">
		                                    <input class="form-control" required="required" type="text">
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-2 col-form-label test-right" for="inputEmail3" style="padding-right:0px !important;">Note/s</label>
		                                <div class="col-sm-10">
		                                    <textarea class="form-control" style="resize: none;"></textarea>
		                                </div>
	                            	</div>
		                    	</div>
		                    	<div class="col-sm-5" style="padding-top:13px;">
		                    		
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-4 col-form-label" for="inputEmail3">Mode of Payment</label>
		                                <div class="col-sm-5">
		                                    <select class="form-control">
		                                    	<option></option>
		                                    	<option>Cash</option>
		                                    	<option>Check</option>
		                                    </select>
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-4 col-form-label" for="inputEmail3">Check No</label>
		                                <div class="col-sm-5">
		                                    <input class="form-control"  type="text">
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-4 col-form-label" for="inputEmail3">Check Date</label>
		                                <div class="col-sm-5">
		                                    <input class="form-control"  type="text">
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-4 col-form-label" for="inputEmail3">Bank Name</label>
		                                <div class="col-sm-5">
		                                    <input class="form-control"  type="text">
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-4 col-form-label" for="inputEmail3">Amount</label>
		                                <div class="col-sm-5">
		                                    <input class="form-control"  type="text">
		                                </div>
	                            	</div>
		                    	</div>
	                    	</div>
	                    	
	                    	<br/>
	                    	<div class="form-group row">
	                    		<div class="col-sm-8">
	                    			<div class="form-group row">
	                               	 	<label style=" padding-right:0px;" class="col-sm-2 col-form-label text-right" for="inputEmail3">TOTAL QTY</label>
		                                <div class="col-sm-2" style="padding-right:0px;">
		                                    <input class="form-control totals_des text-right"  disabled=""  value="0.00" >
		                                </div>
		                                <label style=" padding-right:0px;" class="col-sm-2 col-form-label text-right" for="inputEmail3">TOTAL AMOUNT</label>
		                                 <div class="col-sm-3" style="padding-left:10px;">
		                                    <input class="form-control totals_des text-right" disabled=""  value="0.00">
		                                </div>
		                               
	                            	</div>
	                    		</div>
	                    		 <div class="col-md-4">
	                                 <button style="float:right; " class="btn btn-success btn-icon btn-sm" type="button">
			                    		<span class="ul-btn__icon"><i class="i-Add"></i></span>
			                    		Add Row</button>
	                             </div>
	                    	</div>

	                    	<div class="row" style="margin-top:-20px !important;">
	                    		<div class="col-md-12">
	                    			<div class="table-responsive">
	                                    <table class="table table-sm tbl-condensed">
	                                        <thead>
	                                            <tr>
	                                                <th style="font-weight:500; width:3%;" class="text-center">#</th>
	                                                <th style="font-weight:500;width:10%;"class="text-center">QTY</th>
	                                                <th style="font-weight:500;width:10%;" class="text-center">Unit</th>
	                                                <th style="font-weight:500;width:20%;"class="text-center">Product Code</th>
	                                                <th style="font-weight:500;width:30%;"class="text-center">Product Name</th>
	                                                <th style="font-weight:500;width:10%;" class="text-center">Landed Price</th>
	                                                <th style="font-weight:500;width:15%;" class="text-center">TOTAL</th>
	                                                <th style="font-weight:500;width:3%;" class="text-center">-</th>
	                                            </tr>
	                                        </thead>
	                                        <tbody>
	                                            <tr style="border-bottom:1px solid #dee2e6">
	                                                <td style="padding-top: 4px !important;width:30px;" class="text-center">1</td>
	                                                <td><input type="text" class="form-control input-sm"></td>
	                                                <td><input type="text" class="form-control input-sm" ></td>
	                                                <td><input type="text" class="form-control input-sm"></td>
	                                                <td><input type="text" class="form-control input-sm">
	                                                <td><input type="text" class="form-control input-sm"></td>
	                                                <td><input type="text" class="form-control input-sm" disabled=""></td>
	                                                <td class="text-center">
	                                                    <button style="margin-top:1px;" class="btn btn-danger btn-sm" type="button"><i class="nav-icon i-Close-Window"></i></button>
	                                                </td>
	                                            </tr>

	                                        </tbody>
	                                    </table>
                                	</div>
	                    		</div>
	                    	</div>
	                    </form>
	                </div>
	            </div>
	        </div>
	    </div>
</div>
<script type="text/javascript">
	$('#po_date').datepicker({
	    format: 'mm/dd/yyyy'
	});
</script>

<style type="text/css">
	.table-sm td {
		padding:1px !important;
	}


    select, select.form-control {
 
  background          : url('assets/images/caret-for-select.png');
  background-position : 100% 50% !important;
  background-repeat   : no-repeat !important;
  background-size     : auto 15% !important;

}
table input{
	border-radius: 0px !important;
}
</style>