<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2"><?php echo $title; ?></h1>
         <ul>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/invty_list')?>">Inventory List</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/receive_invty')?>">Receive</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/adjust_invty')?>">Adjusment</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/transfer_invty')?>">Transfer</a></li>
        </ul>
    </div>

     <div class="separator-breadcrumb border-top"></div>
	    <div class="row main_div" id="main_div">
	    	<div class="col-md-10 mb-4">
	            <div class="card text-left">
	                <div class="card-body">
	                    
	                    <ul class="nav nav-tabs" id="myTab" role="tablist">
	                        <li class="nav-item"><a class="nav-link active show" id="home-basic-tab" data-toggle="tab" href="#homeBasic" role="tab" aria-controls="homeBasic" aria-selected="true">Create</a></li>
	                        <li class="nav-item"><a class="nav-link" id="profile-basic-tab" data-toggle="tab" href="#profileBasic" role="tab" aria-controls="profileBasic" aria-selected="false">Transactions</a></li>
	                       
	                    </ul>
	                    <div class="tab-content" id="myTabContent">
	                        <div class="tab-pane fade active show" id="homeBasic" role="tabpanel" aria-labelledby="home-basic-tab">
	                           <div class="row">
							        <div class="col-md-12">
					                    <form class="needs-validation" novalidate="novalidate">
					                    	<div class=" form-group row">
					                    		<div class="col-md-1 offset-md-11">
					                    			<button style="float:right" class="btn btn-info btn-sm btn-icon btn-sm" type="button" data-toggle='modal' data-target='.mod_post'>
						                    		<span style="font-size:15px;" class="ul-btn__icon"><i class="i-Memory-Card-2"></i></span>
						                    		<span style="font-size:15px;" class="ul-btn__text">Save</span></button>
					                    		</div>
					                    	</div>
					                    	<div class="form-group row">
					                    		<div class="col-sm-12">
						                    		
						                    		<div class="form-group row " >
					                                <label class="col-sm-2 col-form-label" for="inputEmail3">Trans No</label>
						                                <div class="col-sm-4">
						                                    <input class="form-control" value="00001" required="required" type="text" id="1">
						                                </div>
					                            	</div>
					                            	<div class="form-group row cstmmargintop">
					                                <label class="col-sm-2 col-form-label" for="inputEmail3">Date</label>
						                                <div class="col-sm-4">
						                                    <input class="form-control" value="<?php echo date('m/d/Y') ?>" required="required" type="text" id="1">
						                                </div>
					                            	</div>
					                            	<div class="form-group row cstmmargintop">
					                                <label class="col-sm-2 col-form-label" for="inputEmail3">Branch</label>
						                                <div class="col-sm-4">
						                                    <select class="form-control">
						                                    	<option value=""></option>
						                                    	<option value="">Main Branch</option>
						                                    </select>
						                                </div>
					                            	</div>
					                            	<div class="form-group row cstmmargintop">
					                                <label class="col-sm-2 col-form-label" for="inputEmail3">Order No</label>
						                                <div class="col-sm-4">
						                                    <input class="form-control"  required="required" type="text" id="1">
						                                </div>
					                            	</div>
					                            	<div class="form-group row cstmmargintop">
					                                <label class="col-sm-2 col-form-label" for="inputEmail3">Customer Name</label>
						                                <div class="col-sm-9">
						                                    <input class="form-control"  required="required" type="text" id="1">
						                                </div>
					                            	</div>
						                    	</div>
					                    	</div>
					                    	
					                    	<div class="form-group row">
					                    		<div class="col-sm-8">
					                    			<div class="form-group row">
					                               	 	<label style="font-size: 13px; padding-right:0px;" class="col-sm-2 col-form-label" for="inputEmail3">TOTAL</label>
						                                <div class="col-sm-3" style="padding-right:0px;">
						                                    <input class="form-control"  disabled="">
						                                </div>
					                            	</div>
					                    		</div>
					                    		<div class="col-md-4">
					                                <button style="float:right; " class="btn btn-success btn-icon btn-sm" type="button">
							                    	<span class="ul-btn__icon"><i class="i-Add"></i></span>
							                    	<span  class="ul-btn__text">Add Row</span></button>
					                            </div>
					                    	</div>
					                    	
					                    	<div class="row" style="margin-top:-18px;">
					                    		<div class="col-md-12">
					                    			<div class="table-responsive">
					                                    <table class="table table-sm">
					                                        <thead>
					                                            <tr>
					                                                <th scope="col" class="text-center">#</th>
					                                                <th scope="col" class="text-center">QTY</th>
					                                                <th scope="col" class="text-center">UNIT</th>
					                                                <th scope="col" class="text-center">BRAND</th>
					                                                <th scope="col" class="text-center">ITEM NAME</th>
					                                                <th scope="col" class="text-center">-</th>
					                                            </tr>
					                                        </thead>
					                                        <tbody>
					                                            <tr style="border-bottom:1px solid #dee2e6">
					                                                <td scope="row"><input style="width:35px" type="text" class="form-control" disabled="" value="1"></td>
					                                                <td><input style="width:130px"  type="text" class="form-control input-sm"></td>
					                                                <td><input value="BALE/S" style="width:95px"  type="text" class="form-control input-sm" disabled=""></td>
					                                                <td><input style="width:200px"  type="text" class="form-control input-sm"></td>
					                                                <td><input style="width:326px"  type="text" class="form-control input-sm"></td>
					                                                <td class="text-center">
					                                                    <button style="margin-top:1px;" class="btn btn-danger btn-sm" type="button"><i class="nav-icon i-Close-Window"></i></button>
					                                                </td>
					                                            </tr>

					                                        </tbody>
					                                    </table>
				                                	</div>
					                    		</div>
					                    	</div>
					                    </form>
							        </div>
							    </div> 

	                        </div>
	                        <div class="tab-pane fade" id="profileBasic" role="tabpanel" aria-labelledby="profile-basic-tab">
	                        	<br/>
	                           <div class="table-responsive">
			                        <table class="display table table-striped table-bordered table-sm" id="deafult_ordering_table" style="width:100%">
			                            <thead>
			                                <tr>
			                                    <th class="text-center" style="width:8px;">LN</th>
			                                    <th class="text-center" style="width:85px;">Trans No</th>
			                                    <th class="text-center" style="width:75px;">Trans Date</th>
			                                    <th class="text-center" style="width:80px;">TOTAL QTY</th>
			                                    <th class="text-center" style="width:80px;">STATUS</th>
			                                    <th class="text-center" style="width:180px;">Actions</th>
			                                </tr>
			                            </thead>
			                            <tbody>
			                                <tr>
			                                    <td class="text-center">1</td>
			                                    <td class="text-center">00001</td>
			                                    <td class="text-center">02/01/2021</td>
			                                    <td class="text-center">P89,000</td>
			                                    <td class="text-center"><span style="font-size: 11px;" class="badge badge-warning">Unposted</span></td>
			                                    <td class="text-center">
			                                        <button class="btn btn-success btn-sm" type="button" data-toggle="modal" data-target=".mod_preview"><i class="nav-icon i-File-Horizontal-Text"></i></button>
			                                        <button class="btn btn-success btn-sm" type="button"><i class="nav-icon i-Billing"></i></button>
			                                        <button id="open_edit" class="btn btn-success btn-sm" type="button"><i class="nav-icon i-Pen-2"></i></button>
			                                        <button  class="btn btn-danger btn-sm" type="button" data-toggle="modal" data-target=".modal_cancel"><i class="nav-icon i-Close-Window"></i></button>
			                                    </td>
			                                </tr>
			                                <tr>
			                                    <td class="text-center">1</td>
			                                    <td class="text-center">00002</td>
			                                    <td class="text-center">02/01/2021</td>
			                                    <td class="text-center">P89,000</td>
			                                    <td class="text-center"><span style="font-size: 11px;" class="badge badge-success">Posted</span></td>
			                                    <td class="text-center">
			                                        <button class="btn btn-success btn-sm" type="button" data-toggle="modal" data-target=".mod_preview"><i class="nav-icon i-File-Horizontal-Text"></i></button>
			                                        <button class="btn btn-success btn-sm" type="button"><i class="nav-icon i-Billing"></i></button>
			                                        <button class="btn btn-warning btn-sm" type="button" data-toggle="modal" data-target=".modal_unpost"><i class="nav-icon i-Repeat"></i></button>
			                                         <button class="btn btn-danger btn-sm" type="button" data-toggle="modal" data-target=".modal_cancel"><i class="nav-icon i-Close-Window"></i></button>
			                                    </td>
			                                </tr>
			                            </tbody>
			                        </table>
			                    </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	   </div>

	   <div class="row edit_div" hidden="true" id="edit_div">
	    	<div class="col-md-10 mb-4">
	            <div class="card text-left">
	                <div class="card-body" style="padding-left:35px;padding-right:35px;">
	                    <div class="row">
					        <div class="col-md-12">
			                    <form class="needs-validation" novalidate="novalidate">
			                    	<div class=" form-group row">
			                    		<div class="col-md-5 offset-md-7">
			                    			<button style="float:right" class="btn btn-default btn-icon btn-sm" type="submit">
				                    		<span style="font-size:15px;" class="ul-btn__icon"><i class="i-Arrow-Back-2"></i></span>
				                    		<span style="font-size:15px;" class="ul-btn__text">Back</span></button>
				                    		<button style="float:right; margin-right:10px;" class="btn btn-info btn-icon btn-sm" type="submit">
				                    		<span style="font-size:15px;" class="ul-btn__icon"><i class="i-Memory-Card-2"></i></span>
				                    		<span style="font-size:15px;" class="ul-btn__text">Update</span></button>
			                    		</div>
			                    	</div>
			                    	<div class="form-group row">
			                    		<div class="col-sm-12">
						                    <div class="form-group row" >
			                                <label class="col-sm-2 col-form-label" for="inputEmail3">Trans No</label>
				                                <div class="col-sm-4">
				                                    <input class="form-control" value="00001" required="required" type="text" id="1">
				                                </div>
			                            	</div>
			                            	<div class="form-group row cstmmargintop">
			                                <label class="col-sm-2 col-form-label" for="inputEmail3">Date</label>
				                                <div class="col-sm-4">
				                                    <input class="form-control" value="<?php echo date('m/d/Y') ?>" required="required" type="text" id="1">
				                                </div>
			                            	</div>
			                            	<div class="form-group row cstmmargintop">
					                                <label class="col-sm-2 col-form-label" for="inputEmail3">Branch</label>
						                                <div class="col-sm-4">
						                                    <select class="form-control">
						                                    	<option value=""></option>
						                                    	<option value="">Main Branch</option>
						                                    </select>
						                                </div>
					                            	</div>
			                            	<div class="form-group row cstmmargintop">
			                                <label class="col-sm-2 col-form-label" for="inputEmail3">Order No</label>
				                                <div class="col-sm-4">
				                                    <input class="form-control"  required="required" type="text" id="1">
				                                </div>
			                            	</div>
			                            	<div class="form-group row cstmmargintop">
			                                <label class="col-sm-2 col-form-label" for="inputEmail3">Customer Name</label>
				                                <div class="col-sm-9">
				                                    <input class="form-control"  required="required" type="text" id="1">
				                                </div>
			                            	</div>
				                    	</div>
			                    	</div>
			                    	
			                    	<div class="form-group row">
			                    		<div class="col-sm-8">
			                    			<div class="form-group row">
			                               	 	<label style="font-size: 13px; padding-right:0px;" class="col-sm-2 col-form-label" for="inputEmail3">TOTAL</label>
				                                <div class="col-sm-3" style="padding-right:0px;">
				                                    <input class="form-control"  disabled="">
				                                </div>
			                            	</div>
			                    		</div>
			                    		<div class="col-md-4">
			                                <button style="float:right; " class="btn btn-success btn-icon btn-sm" type="button">
					                    	<span class="ul-btn__icon"><i class="i-Add"></i></span>
					                    	<span  class="ul-btn__text">Add Row</span></button>
			                            </div>
			                    	</div>
			                    	
			                    	<div class="row" style="margin-top:-18px;">
			                    		<div class="col-md-12">
			                    			<div class="table-responsive">
			                                    <table class="table table-sm">
			                                        <thead>
			                                            <tr>
			                                                <th scope="col" class="text-center">#</th>
			                                                <th scope="col" class="text-center">QTY</th>
			                                                <th scope="col" class="text-center">UNIT</th>
			                                                <th scope="col" class="text-center">BRAND</th>
			                                                <th scope="col" class="text-center">ITEM NAME</th>
			                                                <th scope="col" class="text-center">-</th>
			                                            </tr>
			                                        </thead>
			                                        <tbody>
			                                            <tr style="border-bottom:1px solid #dee2e6">
			                                                <td scope="row"><input style="width:35px" type="text" class="form-control" disabled="" value="1"></td>
			                                                <td><input style="width:130px"  type="text" class="form-control input-sm"></td>
			                                                <td><input value="BALE/S" style="width:95px"  type="text" class="form-control input-sm" disabled=""></td>
			                                                <td><input style="width:200px"  type="text" class="form-control input-sm"></td>
			                                                <td><input style="width:326px"  type="text" class="form-control input-sm"></td>
			                                                <td class="text-center">
			                                                    <button style="margin-top:1px;" class="btn btn-danger btn-sm" type="button"><i class="nav-icon i-Close-Window"></i></button>
			                                                </td>
			                                            </tr>

			                                        </tbody>
			                                    </table>
		                                	</div>
			                    		</div>
			                    	</div>
			                    </form>
					        </div>
					    </div> 
	                </div>
	            </div>
	        </div>
	   </div>
</div>


<div class="modal fade bd-example-modal-lg mod_post" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
                <div class="modal-header" style="border-bottom: none; padding-bottom: 0px;">
                    <div class="alert alert-card alert-danger" role="alert"><strong class="text-capitalize">Warning!</strong> You are about to post this to Inventory.
                            <button class="close" type="button" data-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <div class="modal-body" style="padding-left:40px;  padding-right:40px;">
                   <div class="form-group row">
                   		<div class="col-md-12" style="margin-top:-15px;">
                   			<label class="col-sm-12 col-form-label" for="inputEmail3" style="font-weight:bold; font-size:14px;">Transaction No : 000011</label>
                   		</div>
                   		<div class="col-md-12 cstmmargintop">
                   			<label class="col-sm-12 col-form-label" for="inputEmail3" style="font-weight:bold; font-size:14px;">Transaction Date : 01/02/2021</label>
                   		</div>
                   		<div class="col-md-12 cstmmargintop">
                   			<label class="col-sm-12 col-form-label" for="inputEmail3" style="font-weight:bold; font-size:14px;">Branch : Main</label>
                   		</div>
                   		<div class="col-md-12 cstmmargintop">
                   			<label class="col-sm-12 col-form-label" for="inputEmail3" style="font-weight:bold; font-size:14px;">Order No : </label>
                   		</div>
                   		<div class="col-md-12 cstmmargintop">
                   			<label class="col-sm-12 col-form-label" for="inputEmail3" style="font-weight:bold; font-size:14px;">Customer Name : </label>
                   		</div>
                   		<br/><br/>
                        <div class="col-sm-12">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th scope="col" class="text-center">#</th>
                                                    <th scope="col" class="text-center">QTY</th>
                                                    <th scope="col" class="text-center">UNIT</th>
                                                    <th scope="col" class="text-center">BRAND</th>
                                                    <th scope="col" class="text-center">ITEM NAME</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr style="border-bottom:1px solid #dee2e6">
                                                    <td style="width:5px;" class="text-center">1</td>
                                                    <td style="width:40px;" class="text-center">25</td>
                                                    <td style="width:40px;" class="text-center">BALE/S</td>
                                                    <td style="width:120px;" class="text-center">BRAND</td>
                                                    <td style="width:200px;">Sample Item Name</td>
                                                </tr>
                                                 <tr>
                                                    <td style="font-weight: bold; padding-top:10px !important; padding-bottom:8px !important; border-bottom:1px solid #dedede !important;" class="text-right" > TOTAL</td>
                                                    <td style="width:50px; font-weight: bold;padding-top:10px !important;border-bottom:1px solid #dedede !important;" class="text-center">25</td>
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="border:none; padding-top: 0px;">
                	<button class="btn btn-success btn-sm">Post Transaction</button>
                </div>
            </div>
        </div>
    </div>

<div class="modal fade bd-example-modal-lg mod_preview" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
                <div class="modal-header" style="border-bottom: none; padding-bottom: 0px;">
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <div class="modal-body" style="padding-left:40px;padding-right:40px;">
                   <div class="form-group row">
                   		<div class="col-md-12">
                   			<label class="col-sm-12 col-form-label" for="inputEmail3" style="font-weight:bold; font-size:14px;">Transaction No : 000011</label>
                   		</div>
                   		<div class="col-md-12 cstmmargintop">
                   			<label class="col-sm-12 col-form-label" for="inputEmail3" style="font-weight:bold; font-size:14px;">Transaction Date : 01/02/2021</label>
                   		</div>
                   		<div class="col-md-12 cstmmargintop">
                   			<label class="col-sm-12 col-form-label" for="inputEmail3" style="font-weight:bold; font-size:14px;">Branch : Main</label>
                   		</div>
                   		<div class="col-md-12 cstmmargintop">
                   			<label class="col-sm-12 col-form-label" for="inputEmail3" style="font-weight:bold; font-size:14px;">Order No : </label>
                   		</div>
                   		<div class="col-md-12 cstmmargintop">
                   			<label class="col-sm-12 col-form-label" for="inputEmail3" style="font-weight:bold; font-size:14px;">Customer Name : </label>
                   		</div>
                   		<br/><br/>
                        <div class="col-sm-12">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th scope="col" class="text-center">#</th>
                                                    <th scope="col" class="text-center">QTY</th>
                                                    <th scope="col" class="text-center">UNIT</th>
                                                    <th scope="col" class="text-center">BRAND</th>
                                                    <th scope="col" class="text-center">ITEM NAME</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr style="border-bottom:1px solid #dee2e6">
                                                    <td style="width:5px;" class="text-center">1</td>
                                                    <td style="width:40px;" class="text-center">25</td>
                                                    <td style="width:40px;" class="text-center">BALE/S</td>
                                                    <td style="width:120px;" class="text-center">BRAND</td>
                                                    <td style="width:200px;">Sample Item Name</td>
                                                </tr>
                                                 <tr>
                                                    <td style="font-weight: bold; padding-top:10px !important; padding-bottom:8px !important; border-bottom:1px solid #dedede !important;" class="text-right" > TOTAL</td>
                                                    <td style="width:50px; font-weight: bold;padding-top:10px !important;border-bottom:1px solid #dedede !important;" class="text-center">25</td>
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="modal fade bd-example-modal-sm modal_cancel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Cancel this transaction?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body" style="padding-left:40px;padding-right:40px;">
               <div class="form-group row">
                    <label class="col-sm-12 col-form-label" for="inputEmail3">Add Reason</label>
                    <div class="col-md-12">
                        <textarea class="form-control" style="resize: none; height:60px;"></textarea>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
                <button class="btn btn-success ml-2" type="button">Save changes</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bd-example-modal-sm modal_unpost" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Unpost this Transaction?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body" style="padding-left:40px;padding-right:40px;">
               <div class="form-group row">
                    <label class="col-sm-12 col-form-label" for="inputEmail3">Add Reason</label>
                    <div class="col-md-12">
                        <textarea class="form-control" style="resize: none; height:60px;"></textarea>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
                <button class="btn btn-success ml-2" type="button">Save changes</button>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo base_url('assets/js/plugins/jquery-3.3.1.min.js'); ?>"></script>
<script type="text/javascript" >
	$("#open_edit").click(function(){
		document.getElementById('edit_div').hidden = false;
		document.getElementById('main_div').hidden = true;
		
	});
</script>

<style type="text/css">
	.table-sm td {
		padding:3px !important;
	}
		 select, select.form-control {
 
  background          : url('assets/images/caret-for-select.png');
  background-position : 100% 50% !important;
  background-repeat   : no-repeat !important;
  background-size     : auto 15% !important;

}
</style>