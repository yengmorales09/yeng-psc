<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2"><?php echo $title; ?></h1>
        <ul>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/receive_invty')?>">Receive</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/return_invty')?>">Return</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/adjust_invty')?>">Adjusment</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/transfer_invty')?>">Transfer</a></li>
        </ul>
    </div>

     <div class="separator-breadcrumb border-top"></div>
     <br/>
        <div class="col-md-11">
            <div class="card">
                <div class="card-body">
                    <br/>
                     <div class="col-md-12">
                        <div class="row row-xs">
                           
                            <div class="col-md-3">
                                <select class="form-control">
                                  <option selected="">FILTER BRANCH</option>
                                  <option>Branch 2</option>
                                  <option>Branch 3</option>
                                </select>
                            </div>
                             <div class="col-md-3">
                                <select class="form-control">
                                  <option selected="">FILTER BRAND</option>
                                  <option>Branch 2</option>
                                  <option>Branch 3</option>
                                </select>
                            </div>
                           
                            <div class="col-md-6 mt-3 mt-md-0">
                                    <button style="float:right; padding-top:1px; padding-bottom:1px; font-size: 10px; margin-left:10px;" class="btn btn-success btn-icon btn-sm" data-toggle="modal" data-target=".mod_add" type="button">
                                    <span style="font-size:15px;" class="ul-btn__icon"><i class="nav-icon i-Billing"></i></span>
                                    <span style="font-size:12px;" class="ul-btn__text">Print</span></button>

                                    <button style="float:right; padding-top:1px; padding-bottom:1px; font-size: 10px;" class="btn btn-info btn-icon btn-sm" data-toggle="modal" data-target=".mod_add" type="button">
                                    <span style="font-size:15px;" class="ul-btn__icon"><i class="i-File-Excel"></i></span>
                                    <span style="font-size:12px;" class="ul-btn__text">Export</span></button>
                            </div>
                        </div>
                    </div>

                    <br/><br/>
                     <div class="table-responsive">
                        <table class="display table table-striped table-bordered table-sm" id="deafult_ordering_table" style="width:100%">
                            <thead>
                                <tr>
                                    <th class="text-center" style="width:8px;">#</th>
                                    <th class="text-center" style="width:85px;">BRAND</th>
                                    <th class="text-center">ITEM NAME</th>
                                    <th class="text-center" style="width:80px;">UNIT</th>
                                    <th class="text-center" style="width:80px;">ON STOCK</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="text-center">1</td>
                                    <td class="text-center">Brand</td>
                                    <td>Mixed Shorts</td>
                                    <td class="text-center">BALE/S</td>
                                    <td class="text-center">1</td>
                                </tr>
                                <tr>
                                    <td class="text-center">1</td>
                                    <td class="text-center">Tank Tops</td>
                                    <td>Mixed Shorts</td>
                                    <td class="text-center">BALE/S</td>
                                    <td class="text-center">1</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</div>




<style type="text/css">
    .btn-secondary:focus, .btn-outline-secondary:focus {
        box-shadow: 0 8px 25px -4px #52495a !important;}

    select, select.form-control {
 
  background          : url('assets/images/caret-for-select.png');
  background-position : 100% 50% !important;
  background-repeat   : no-repeat !important;
  background-size     : auto 15% !important;

}

</style>
