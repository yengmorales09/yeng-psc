
<div class="main-content">
        <br/><br/>
        <div class="col-md-5 offset-md-3">
            <div class="card">
                <div class="card-body">
                    <br/>
                            
                    <br/>
                    <div class="form-group row">
                        <div class="col-sm-12">
                            <div class="form-group row cstmmargintop">
                            <label class="col-sm-5 col-form-label" for="inputEmail3">Type New Password</label>
                                <div class="col-sm-7">
                                    <input id="new_pass" class="form-control" required="required" type="Password" autocomplete="off">
                                </div>
                            </div>
                            <div class="form-group row cstmmargintop">
                            <label class="col-sm-5 col-form-label" for="inputEmail3">Confirm  Password</label>
                                <div class="col-sm-7">
                                    <input id="con_new_pass" class="form-control" required="required" type="Password" autocomplete="off">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=" form-group row">
                                <div class="col-md-1 offset-md-11">
                                    <button id="update" style="float:right" class="btn btn-success btn-icon btn-sm" data-toggle="modal" data-target=".mod_add" type="button">
                                    <span style="font-size:15px;" class="ul-btn__icon"><i class="i-Memory-Card-2"></i></span>
                                    <span style="font-size:15px;" class="ul-btn__text">Update</span></button>
                                </div>
                            </div>
                </div>
            </div>
        </div>
</div>

<script type="text/javascript">
    $("#update").click(function(){
        new_pass = $("#new_pass").val();
        con_new_pass = $("#con_new_pass").val();
        user_pass = $("#con_new_pass").val();

        if (new_pass == "" && con_new_pass == "") {
            swal("Please input password!","", "warning");
        }else{
            if (new_pass == con_new_pass) {

                var user_id = "<?php echo $this->session->userdata('id');?>";

                var update_password = {
                    user_pass : user_pass,
                    user_id : user_id
                }
                swal({
                title: "Change Password",
                text: "Are you sure you want to change password?",
                icon: "info",
                buttons: [
                  'No',
                  'Yes'
                ],
                dangerMode: true,
              }).then(function(isConfirm) {
                if (isConfirm) {
                  swal({
                    title: 'Password changed successfull!',
                    text: '',
                    icon: 'success'
                  }).then(function() {
                     var data = {update_password : update_password};
                     $.ajax({
                      data: data, 
                      type: "POST", 
                      url: "<?php echo base_url('Pages/change_password'); ?>" , 
                      dataType: "json", 
                      crossOrigin: false, 
                      beforeSend: function () {
                      }, success: function (result) {
                        /*swal("Succesfully Save!", "", "success").then(val=>{window.location = "<?php echo base_url('logout') ?>"});*/
                        window.location = "<?php echo base_url('logout') ?>";
                      }, failure: function (msg) {
                          console.log("Error connecting to server...");
                      }, error: function (status) {

                      }, xhr: function () {
                          var xhr = $.ajaxSettings.xhr();
                          xhr.onprogress = function (evt) {
                              $("body").css("cursor", "wait");
                          };
                          xhr.onloadend = function (evt) {
                              $("body").css("cursor", "default");
                          };
                          return xhr;
                      }
                      });
                  });
                } else {
                  swal("Change Password", "Password change", "error");
                   
                }
              })

            }else{
                swal("Password dont match!","", "warning");
            }
        }

        
    });
</script>