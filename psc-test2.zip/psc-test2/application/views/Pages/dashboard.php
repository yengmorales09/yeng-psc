<div class="main-content">
    <!-- <div class="breadcrumb">
        <h1 class="mr-2">Today Upd</h1>
        <ul>
            <li style="font-size: 15px;"><a href="">Current Month</a></li>
            <li style="font-size: 15px;">ALL</li>
        </ul>
    </div>
    <div class="separator-breadcrumb border-top"></div> -->
    <div class="row">
    	<div class="col-md-2">
    		<div class="card">
    			<div class="card-body text-center"><i style="font-size:20px;" class="i-Money-2"></i>
	                <p class="text-muted mt-2 mb-2">NEW ORDERS</p>
	                <p class="text-primary text-24 line-height-1 m-0">21</p>
            	</div>
    		</div>
    	</div>
    	<div class="col-md-2">
    		<div class="card">
    			<div class="card-body text-center"><i style="font-size:20px;" class="i-Truck"></i>
	                <p class="text-muted mt-2 mb-2">DELIVERIES</p>
	                <p class="text-primary text-24 line-height-1 m-0">5</p>
            	</div>
    		</div>
    	</div>
    	<div class="col-md-2">
    		<div class="card">
    			<div class="card-body text-center"><i style="font-size:20px;" class="i-Full-Basket"></i>
	                <p class="text-muted mt-2 mb-2">INVENTORY</p>
	                <p class="text-primary text-24 line-height-1 m-0">5</p>
            	</div>
    		</div>
    	</div>
    </div>
    <br/><br/>
    <div class="row">
    	<div class="col-md-6">
    		<div class="card">
	            <div class="card-body">
	            	 <div class="card-title">Sales Per Brand</div>
	                <div class="table-responsive">
	                    <div id="sales_table_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer"><div class="row"><div class="col-sm-12 col-md-6"><div class="dataTables_length" id="sales_table_length"><label>Show <select name="sales_table_length" aria-controls="sales_table" class="form-control form-control-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label></div></div><div class="col-sm-12 col-md-6"><div id="sales_table_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="sales_table"></label></div></div></div><div class="row"><div class="col-sm-12"><table class="table dataTable-collapse text-center dataTable no-footer" id="sales_table" role="grid" aria-describedby="sales_table_info">
	                        <thead>
	                            <tr role="row"><th scope="col" class="sorting_asc" tabindex="0" aria-controls="sales_table" rowspan="1" colspan="1" aria-sort="ascending" aria-label="#: activate to sort column descending" style="width: 20px;">#</th><th scope="col" class="sorting" tabindex="0" aria-controls="sales_table" rowspan="1" colspan="1" aria-label="Product: activate to sort column ascending" style="width: 76px;">Brand</th><th scope="col" class="sorting" tabindex="0" aria-controls="sales_table" rowspan="1" colspan="1" aria-label="Price: activate to sort column ascending" style="width: 52.8px;">QTY</th></tr>
	                        </thead>
	                        <tbody>
	                            
	                            
	                            
	                        <tr role="row" class="odd">
	                                <th scope="row" class="sorting_1">1</th>
	                                <td>Brand 1</td>
	                                <td>30</td>
	                            </tr><tr role="row" class="even">
	                                <th scope="row" class="sorting_1">2</th>
	                                <td>Brand 2</td>
	                                <td>300</td>
	                            </tr><tr role="row" class="odd">
	                                <th scope="row" class="sorting_1">3</th>
	                                <td>Brand 3</td>
	                                <td>30</td>
	                            </tr></tbody>
	                    </table></div></div><div class="row"><div class="col-sm-12 col-md-5"><div class="dataTables_info" id="sales_table_info" role="status" aria-live="polite">Showing 1 to 3 of 3 entries</div></div><div class="col-sm-12 col-md-7"><div class="dataTables_paginate paging_simple_numbers" id="sales_table_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="sales_table_previous"><a href="#" aria-controls="sales_table" data-dt-idx="0" tabindex="0" class="page-link">Previous</a></li><li class="paginate_button page-item active"><a href="#" aria-controls="sales_table" data-dt-idx="1" tabindex="0" class="page-link">1</a></li><li class="paginate_button page-item next disabled" id="sales_table_next"><a href="#" aria-controls="sales_table" data-dt-idx="2" tabindex="0" class="page-link">Next</a></li></ul></div></div></div></div>
	                </div>
	            </div>
	        </div>
    	</div>
    	<div class="col-md-6">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card-title">This Year Sales</div>
                    <div id="echartBar" style="height: 300px; -webkit-tap-highlight-color: transparent; user-select: none; position: relative;" _echarts_instance_="ec_1614653820952"><div style="position: relative; overflow: hidden; width: 840px; height: 300px; padding: 0px; margin: 0px; border-width: 0px; cursor: default;"><canvas data-zr-dom-id="zr_0" width="1050" height="375" style="position: absolute; left: 0px; top: 0px; width: 840px; height: 300px; user-select: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); padding: 0px; margin: 0px; border-width: 0px;"></canvas></div><div style="position: absolute; display: none; border-style: solid; white-space: nowrap; z-index: 9999999; transition: left 0.4s cubic-bezier(0.23, 1, 0.32, 1) 0s, top 0.4s cubic-bezier(0.23, 1, 0.32, 1) 0s; background-color: rgba(0, 0, 0, 0.8); border-width: 0px; border-color: rgb(51, 51, 51); border-radius: 4px; color: rgb(255, 255, 255); font: 14px / 21px &quot;Microsoft YaHei&quot;; padding: 5px; left: 95px; top: 228px; pointer-events: none;">Online<br><span style="display:inline-block;margin-right:5px;border-radius:10px;width:10px;height:10px;background-color:#bcbbdd;"></span>Jan: 35,000</div></div>
                </div>
            </div>
        </div>
    </div>
</div>
