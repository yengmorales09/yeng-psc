<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2"><?php echo $title; ?></h1>
        <ul>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/create_so')?>">Create Delivery</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/reports_dr')?>">Reports</a></li>
        </ul>
    </div>

     <div class="separator-breadcrumb border-top"></div>
     <br/>
        <div class="col-md-11">
            <div class="card">
                <div class="card-body">
                    <br/>
                     <div class="col-md-12">
                          <div class="btn-group" role="group" aria-label="Basic example">
                            <button id="allbtn" class="btn btn-secondary allbtn" type="button">ALL</button>
                            <button class="btn btn-secondary" type="button">CANCELLED</button>
                        </div>
                     </div>

                     <br/><br/>
                     <div class="table-responsive">
                        <table class="display table table-striped table-bordered table-sm" id="deafult_ordering_table" style="width:100%">
                            <thead>
                                <tr>
                                    <th class="text-center" style="width:8px;">LN</th>
                                    <th class="text-center" style="width:85px;">DR No</th>
                                    <th class="text-center" style="width:75px;">DR Date</th>
                                    <th class="text-center">Customer</th>
                                    <th class="text-center" style="width:80px;">QTY</th>
                                    <th class="text-center" style="width:80px;">Amount</th>
                                    <th class="text-center" style="width:180px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="text-center">1</td>
                                    <td class="text-center">00001</td>
                                    <td class="text-center">02/01/2021</td>
                                    <td>Sample Customer Name</td>
                                    <td class="text-center">10</td>
                                    <td class="text-center">P25,000</td>
                                    <td class="text-center">
                                        <button class="btn btn-success btn-sm" type="button" data-toggle="modal" data-target=".bd-example-modal-lg"><i class="nav-icon i-File-Horizontal-Text"></i></button>
                                        <button class="btn btn-success btn-sm" type="button"><i class="nav-icon i-Billing"></i></button>
                                        <button onclick="location.href='<?php echo base_url('/edit_dr') ?>'" class="btn btn-success btn-sm" type="button"><i class="nav-icon i-Pen-2"></i></button>
                                        <button class="btn btn-danger btn-sm" type="button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="nav-icon i-Close-Window"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-center">2</td>
                                    <td class="text-center">00001</td>
                                    <td class="text-center">02/01/2021</td>
                                    <td>Sample Customer Name</td>
                                    <td class="text-center">10</td>
                                    <td class="text-center">P25,000</td>
                                    <td class="text-center">
                                        <button class="btn btn-success btn-sm" type="button" data-toggle="modal" data-target=".bd-example-modal-lg"><i class="nav-icon i-File-Horizontal-Text"></i></button>
                                        <button class="btn btn-success btn-sm" type="button"><i class="nav-icon i-Billing"></i></button>
                                        <button onclick="location.href='<?php echo base_url('/edit_dr') ?>'" class="btn btn-success btn-sm" type="button"><i class="nav-icon i-Pen-2"></i></button>
                                        <button class="btn btn-danger btn-sm" type="button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="nav-icon i-Close-Window"></i></button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</div>

<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg" style="max-width:950px !important;">
        <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">View Order</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <div class="modal-body" style="padding-left:40px;padding-right:40px; ">
                    
                   <div class="form-group row">
                        <div class="col-sm-12">
                            <div class="form-group row">
                            <label class="col-sm-2 col-form-label" for="inputEmail3">DR No</label>
                                <div class="col-sm-4">
                                    <input class="form-control cstminputvw" value="00001" style="pointer-events: none;">
                                </div>
                            </div>
                            <div class="form-group row cstmmargintop">
                            <label class="col-sm-2 col-form-label" for="inputEmail3">DR Date</label>
                                <div class="col-sm-4">
                                    <input class="form-control cstminputvw" value="00001" style="pointer-events: none;">
                                </div>
                            </div>
                            <div class="form-group row cstmmargintop">
                            <label class="col-sm-2 col-form-label" for="inputEmail3">Order No</label>
                                <div class="col-sm-4">
                                    <input class="form-control cstminputvw" value="00001" style="pointer-events: none;">
                                </div>
                            </div>
                            <div class="form-group row cstmmargintop">
                            <label class="col-sm-2 col-form-label" for="inputEmail3">Order Type</label>
                                <div class="col-sm-4">
                                    <input class="form-control cstminputvw" value="WITH LOGO" style="pointer-events: none;">
                                </div>
                            </div>
                            <div class="form-group row cstmmargintop">
                            <label class="col-sm-2 col-form-label" for="inputEmail3">Customer</label>
                                <div class="col-sm-9">
                                    <input class="form-control cstminputvw" value="Sample Customer Name" style="pointer-events: none;">
                                </div>
                            </div>
                             <div class="form-group row cstmmargintop">
                            <label class="col-sm-2 col-form-label" for="inputEmail3">Address</label>
                                <div class="col-sm-9">
                                    <input class="form-control cstminputvw" value="Pasay City" style="pointer-events: none;">
                                </div>
                            </div>
                            <div class="form-group row cstmmargintop">
                            <label class="col-sm-2 col-form-label" for="inputEmail3">Contact</label>
                                <div class="col-sm-4">
                                    <input class="form-control cstminputvw" value="09087656" style="pointer-events: none;">
                                </div>
                            </div>
                             <div class="form-group row cstmmargintop">
                            <label class="col-sm-2 col-form-label" for="inputEmail3">Delivery Date</label>
                                <div class="col-sm-4">
                                    <input class="form-control cstminputvw" value="" style="pointer-events: none;">
                                </div>
                            </div>
                            <div class="form-group row cstmmargintop">
                            <label class="col-sm-2 col-form-label" for="inputEmail3">Note</label>
                                <div class="col-sm-9">
                                    <input class="form-control cstminputvw" value="" style="pointer-events: none;">
                                </div>
                            </div>

                            <br/>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th scope="col" class="text-center">#</th>
                                                    <th scope="col" class="text-center">QTY</th>
                                                    <th scope="col" class="text-center">UNIT</th>
                                                    <th scope="col" class="text-center">BRAND</th>
                                                    <th scope="col" class="text-center">ITEM NAME</th>
                                                    <th scope="col" class="text-center">PRICE TYPE</th>
                                                    <th scope="col" class="text-center">PRICE</th>
                                                    <th scope="col" class="text-center">DISCOUNT</th>
                                                    <th scope="col" class="text-center">TOTAL</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr style="border-bottom:1px solid #dee2e6">
                                                    <td style="width:5px;" class="text-center">1</td>
                                                    <td style="width:40px;" class="text-center">25</td>
                                                    <td style="width:40px;" class="text-center">BALE/S</td>
                                                    <td style="width:120px;" class="text-center">BRAND</td>
                                                    <td style="width:180px;">Sample Item Name</td>
                                                    <td style="width:100px;" class="text-center">Retail</td>
                                                    <td style="width:50px;" class="text-center">6,000</td>
                                                    <td style="width:40px;" class="text-center">0</td>
                                                    <td style="width:90px;" class="text-center">50,000</td>
                                                </tr>
                                                 <tr style="border-bottom:1px solid #dee2e6">
                                                    <td style=" border-bottom:1px solid white !important; font-weight: bold" class="text-right" colspan="8"> TOTAL</td>
                                                    <td style="width:50px; font-weight: bold" class="text-center">50,000</td>
                                                </tr>
                                                <tr style="border-bottom:1px solid #dee2e6">
                                                    <td style=" border-bottom:1px solid white !important; font-weight: bold" class="text-right" colspan="8"> Discount</td>
                                                    <td style="width:50px; font-weight: bold" class="text-center">0</td>
                                                </tr>
                                               
                                                <tr style="border-bottom:1px solid #dee2e6">
                                                    <td style=" border-bottom:1px solid white !important; font-weight: bold" class="text-right" colspan="8"> Delivery Charge</td>
                                                    <td style="width:50px; font-weight: bold" class="text-center">0</td>
                                                </tr>
                                                <tr style="border-bottom:1px solid #dee2e6">
                                                    <td style=" border-bottom:1px solid white !important; font-weight: bold" class="text-right" colspan="8"> GRAND TOTAL</td>
                                                    <td style="width:50px; font-weight: bold" class="text-center">50,000</td>
                                                </tr>


                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Cancel DR?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body" style="padding-left:40px;padding-right:40px;">
               <div class="form-group row">

                    <label class="col-sm-12 col-form-label" for="inputEmail3">Add Reason</label>
                    <div class="col-md-12">
                        <textarea class="form-control" style="resize: none; height:60px;"></textarea>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
                <button class="btn btn-success ml-2" type="button">Save changes</button>
            </div>
        </div>
    </div>
</div>

<!-- <script src="<?php echo base_url('assets/js/plugins/jquery-3.3.1.min.js') ?>"></script>
<script type="text/javascript">
   

    $(document).ready(function(){
         $(".allbtn").trigger('click');
         alert("sjh")
    });


</script> -->
<style type="text/css">
    .btn-secondary:focus, .btn-outline-secondary:focus {
        box-shadow: 0 8px 25px -4px #52495a !important;}

</style>
