<div class="main-content">
    <div class="breadcrumb">
        <h1 class="mr-2"><?php echo $title; ?></h1>
        <ul>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/list_dr')?>">Delivery List</a></li>
            <li><a style="font-size: 15px;" href="<?php echo base_url('/reports_dr')?>">Reports</a></li>
        </ul>
    </div>

     <div class="separator-breadcrumb border-top"></div>
	    <div class="row">
	        <div class="col-md-12">
	            <div class="card mb-4">
	                <div class="card-body" style="padding-left:30px;padding-right:30px;">
	                    <form class="needs-validation" novalidate="novalidate">
	                    	<div class=" form-group row">
	                    		<div class="col-md-5 offset-md-7">
	                    			<button style="float:right" class="btn btn-default btn-icon" type="submit">
		                    		<span style="font-size:15px;" class="ul-btn__icon"><i class="i-Arrow-Back-2"></i></span>
		                    		<span style="font-size:15px;" class="ul-btn__text">Back</span></button>
		                    		<button style="float:right; margin-right:10px;" class="btn btn-info btn-icon" type="submit">
		                    		<span style="font-size:15px;" class="ul-btn__icon"><i class="i-Memory-Card-2"></i></span>
		                    		<span style="font-size:15px;" class="ul-btn__text">Update</span></button>
	                    		</div>
	                    	</div>
	                    	<div class="form-group row">
	                    		<div class="col-sm-8">
	                    			<div class="form-group row">
	                                <label class="col-sm-2 col-form-label" for="inputEmail3">DR No</label>
		                                <div class="col-sm-4">
		                                    <input class="form-control input-sm" value="" required="required" type="text" id="1">
		                                </div>
	                            	</div>
		                    		<div class="form-group row cstmmargintop">
	                                <label class="col-sm-2 col-form-label" for="inputEmail3">Date</label>
		                                <div class="col-sm-4">
		                                    <input class="form-control input-sm" value="<?php echo date('m/d/Y') ?>" required="required" type="text" id="1">
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-2 col-form-label" for="inputEmail3">Order No</label>
		                                <div class="col-sm-4">
		                                    <input class="form-control input-sm" value="00001" required="required" type="text" id="1">
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-2 col-form-label" for="inputEmail3">Customer</label>
		                                <div class="col-sm-10">
		                                    <input class="form-control" required="required" type="text" id="2" value="Sample Customer Name">
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-2 col-form-label" for="inputEmail3">Address</label>
		                                <div class="col-sm-10">
		                                    <input class="form-control" required="required" type="text" id="3" value="Sample Address">
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-2 col-form-label" for="inputEmail3">Contact</label>
		                                <div class="col-sm-4">
		                                    <input class="form-control" required="required" type="text" id="4" value="09878900">
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-2 col-form-label" for="inputEmail3">Delivery Date</label>
		                                <div class="col-sm-4">
		                                    <input class="form-control" type="text" id="4" value="">
		                                </div>
	                            	</div>
	                            	<div class="form-group row cstmmargintop">
	                                <label class="col-sm-2 col-form-label" for="inputEmail3">Delivery Fee</label>
		                                <div class="col-sm-4">
		                                    <input class="form-control" type="text" id="4" value="">
		                                </div>
	                            	</div>
		                    	</div>
		                    	<div class="col-sm-4">
		                    		<br/><br/>
		                    		<div class="form-group row cstmmargintop">
	                                <label class="col-sm-3 col-form-label" for="inputEmail3">Note</label>
		                                <div class="col-sm-9">
		                                    <textarea class="form-control" style="resize: none; height: 122px;"></textarea>
		                                </div>
	                            	</div>
		                    	</div>
	                    	</div>
	                    	
	                    	<br/>
	                    	<div class="form-group row">
	                    		<div class="col-sm-8">
	                    			<div class="form-group row">
	                               	 	<label style="font-size: 13px; padding-right:0px;" class="col-sm-2 col-form-label" for="inputEmail3">GRAND TOTAL</label>
		                                <div class="col-sm-2" style="padding-right:0px;">
		                                    <input class="form-control"  disabled="" value="4,950">
		                                </div>
		                                <div class="col-sm-2" style="padding-left:0px; padding-right:0px;">
		                                    <input class="form-control" placeholder="Discount Here . .">
		                                </div>
		                                 <div class="col-sm-2" style="padding-left:0px;">
		                                    <input class="form-control" disabled="" value="4,950">
		                                </div>
	                            	</div>
	                    		</div>
	                    		<div class="col-md-4">
	                                        <button style="float:right; " class="btn btn-success btn-icon btn-sm" type="button">
			                    		<span class="ul-btn__icon"><i class="i-Add"></i></span>
			                    		<span  class="ul-btn__text">Add Row</span></button>
	                                    </div>
	                    	</div>

	                    	<div class="row" style="margin-top:5px;">
	                    		<div class="col-md-12">
	                    			<div class="table-responsive">
	                                    <table class="table table-sm">
	                                        <thead>
	                                            <tr>
	                                                <th scope="col" class="text-center">#</th>
	                                                <th scope="col" class="text-center">QTY</th>
	                                                <th scope="col" class="text-center">UNIT</th>
	                                                <th scope="col" class="text-center">BRAND</th>
	                                                <th scope="col" class="text-center">ITEM NAME</th>
	                                                <th scope="col" class="text-center">PRICE TYPE</th>
	                                                <th scope="col" class="text-center">UNIT PRICE</th>
	                                                <th scope="col" class="text-center">DISCOUNT</th>
	                                                <th scope="col" class="text-center">TOTAL</th>
	                                                <th scope="col" class="text-center">-</th>
	                                            </tr>
	                                        </thead>
	                                        <tbody>
	                                            <tr style="border-bottom:1px solid #dee2e6">
	                                                <td scope="row"><input style="width:35px" type="text" class="form-control" disabled="" value="1"></td>
	                                                <td><input style="width:80px"  type="text" class="form-control input-sm text-right" value="1"></td>
	                                                <td><input value="BALE/S" style="width:75px"  type="text" class="form-control input-sm" disabled=""></td>
	                                                <td><input style="width:180px"  type="text" class="form-control input-sm" value="BRAND"></td>
	                                                <td><input style="width:200px"  type="text" class="form-control input-sm" value="MIXED SHORTS"></td>
	                                                 <td> <select class="form-control" style="width:100px;">
							                                  <option selected="">Retail</option>
							                                  <option>Container</option>
							                                  <option>Wholesale</option>
							                                </select></td>
	                                                <td><input style="width:95px"  type="text" class="form-control input-sm" value="5,000"></td>
	                                                <td><input style="width:95px"  type="text" class="form-control input-sm" value="50"></td>
	                                                <td><input style="width:145px"  type="text" class="form-control input-sm" value="4,950"></td>
	                                                <td class="text-center">
	                                                    <button style="margin-top:3px;" class="btn btn-danger btn-sm" type="button"><i class="nav-icon i-Close-Window"></i></button>
	                                                </td>
	                                            </tr>

	                                        </tbody>
	                                    </table>
                                	</div>
	                    		</div>
	                    	</div>
	                    </form>
	                </div>
	            </div>
	        </div>
	    </div>
</div>

<style type="text/css">
	.table-sm td {
		padding:1px !important;
	}


    select, select.form-control {
 
  background          : url('assets/images/caret-for-select.png');
  background-position : 100% 50% !important;
  background-repeat   : no-repeat !important;
  background-size     : auto 15% !important;

}
</style>