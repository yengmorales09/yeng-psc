<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pages_Model extends CI_Model{
    function __construct(){
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->library('session');
        $CI = &get_instance();
        date_default_timezone_set("Asia/Manila");

    }

    public function get_max_po() {     
        $query=$this->db->query("SELECT COALESCE(MAX(replace(po_no,'PO-','')),0) AS po_no FROM trans_po_hdr");  
        return $query->result();
     }
    


}