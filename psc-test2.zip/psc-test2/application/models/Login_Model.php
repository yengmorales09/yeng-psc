<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login_Model extends CI_Model{
    function __construct(){
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->library('session');
        $CI = &get_instance();
        date_default_timezone_set("Asia/Manila");

    }

	public function login($user_name, $user_pass){
        $query = $this->db->get_where('user_accounts', array('user_name'=>$user_name, 'user_pass'=>$user_pass));
        return $query->row_array();
    }

    public function edit_password($update_password) {
        $this->db->trans_begin();

        $this->db->set('user_pass', $update_password['password']);      
        $this->db->where("user_code", $update_password['user_code']); 
        $this->db->update('user_accounts');
    
        if($this->db->trans_status() === FALSE){
          $db_error = "";
          $db_error = $this->this->db->error();
          $this->db->trans_rollback();
          return $db_error;
        }else{
            $this->db->trans_commit();
            return true;
        }
    }

    function get_acces($user_code){
        $this->db->select('*');
        $this->db->from('mast_users_access');
        $this->db->where('user_code',$user_code);
        $query = $this->db->get();
        return $query->result();
        
    }

    public function change_password($update_password) {
        $this->db->trans_begin();

        $this->db->set('user_pass', $update_password['user_pass']);      
        $this->db->where("id", $update_password['user_id']); 
        $this->db->update('user_accounts');
    
        if($this->db->trans_status() === FALSE){
          $db_error = "";
          $db_error = $this->this->db->error();
          $this->db->trans_rollback();
          return $db_error;
        }else{
            $this->db->trans_commit();
            return true;
        }
    }
    


}