<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->helper('url');
		$this->load->library('session');
		 $this->load->model('Login_Model');
		 $this->load->model('Pages_Model');
	}


	public function index(){
		//load session library
		$this->load->library('session');
		
		//restrict users to go back to login if session has been set
		if($this->session->userdata('user')){	
				redirect('create_po');
		}
		else{
			$this->load->view('Pages/login'); 	
		}
	}

	public function dashboard()
	{
		$titles = array('title' => 'Dashboard','page' =>'dashboard');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/dashboard');
		$this->load->view('Pages/common/footer');
	}


	public function create_po()
	{
		if($this->session->userdata('user')){
			$titles = array('title' => 'Create Purchase Order','page' =>'purchase');
			$data['max_po'] = $this->Pages_Model->get_max_po();
			$this->load->view('Pages/common/header');
			$this->load->view('Pages/common/top-header');
			$this->load->view('Pages/common/left-sidebar',$titles);
			$this->load->view('Pages/purchases/create_po',$data,$titles);
			$this->load->view('Pages/common/footer');
        }else{
                redirect('/');
        }
        
	}


	public function list_po()
	{
		$titles = array('title' => 'Purchase Order List','page' =>'purchase');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/purchases/list_po',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function create_so()
	{
		$titles = array('title' => 'Create Order','page' =>'order');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/sales/create_so',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function list_so()
	{
		$titles = array('title' => 'Order List','page' =>'order');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/sales/list_so',$titles);
		$this->load->view('Pages/common/footer');
	}


	public function reports_so()
	{
		$titles = array('title' => 'Sales Reports','page' =>'order');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/sales/reports_so',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function edit_so()
	{
		$titles = array('title' => 'Edit Order','page' =>'order');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/sales/edit_so',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function so_list_dr()
	{
		$titles = array('title' => 'Create Delivery','page' =>'delivery');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/dr/so_list_dr',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function create_dr()
	{
		$titles = array('title' => 'Create Delivery','page' =>'delivery');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/dr/create_dr',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function list_dr()
	{
		$titles = array('title' => 'Delivery List','page' =>'delivery');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/dr/list_dr',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function edit_dr()
	{
		$titles = array('title' => 'Edit DR','page' =>'delivery');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/dr/edit_dr',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function reports_dr()
	{
		$titles = array('title' => 'Delivery Reports','page' =>'delivery');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/dr/reports_dr',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function invty_list()
	{
		$titles = array('title' => 'Inventory List','page' =>'inventory');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/inventory/invty_list',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function receive_invty()
	{
		$titles = array('title' => 'Receive Stocks','page' =>'inventory');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/inventory/receive_invty',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function return_invty()
	{
		$titles = array('title' => 'Return Stocks','page' =>'inventory');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/inventory/return_invty',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function adjust_invty()
	{
		$titles = array('title' => 'Stock Adjustment','page' =>'inventory');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/inventory/adjust_invty',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function transfer_invty()
	{
		$titles = array('title' => 'Transfer Stock','page' =>'inventory');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/inventory/transfer_invty',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function branch_fm()
	{
		$titles = array('title' => 'Branches','page' =>'file_mgmt');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/fm/branch_fm',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function items_fm()
	{
		$titles = array('title' => 'Items','page' =>'file_mgmt');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/fm/items_fm',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function cust_fm()
	{
		$titles = array('title' => 'Customers','page' =>'file_mgmt');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/fm/cust_fm',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function brands_fm()
	{
		$titles = array('title' => 'Brands','page' =>'file_mgmt');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/fm/brands_fm',$titles);
		$this->load->view('Pages/common/footer');
	}

	public function users_fm()
	{
		$titles = array('title' => 'Brands','page' =>'file_mgmt');
		$this->load->view('Pages/common/header');
		$this->load->view('Pages/common/top-header');
		$this->load->view('Pages/common/left-sidebar',$titles);
		$this->load->view('Pages/fm/users_fm',$titles);
		$this->load->view('Pages/common/footer');
	}

	/////////////


	public function validate_login(){
		$this->load->library('session');

		$user_name = $_POST['user_name'];
		$user_pass = $_POST['user_pass'];
		$data = $this->Login_Model->login($user_name, $user_pass);
	
		if($data){
			if($data['user_status']=="active"){
					$this->session->set_userdata('user', $data);
					$this->session->set_userdata($data);
					redirect('/create_po');
			}else{
				header('location:'.base_url().$this->index());
				$this->session->set_flashdata('error','This User Is Inactive. Try Again.');
			}
		}else{
			header('location:'.base_url().$this->index());
			$this->session->set_flashdata('error','Invalid login details. Try Again.');
		
		}
		
	}


	public function logout(){
		//load session library
		$this->load->library('session');
		$this->session->unset_userdata('user');
		redirect('/');
	}

    
	public function change_pass()
	{
		$titles = array('title' => 'Change Password','page' =>'file_mgmt');
		if($this->session->userdata('user')){
			$this->load->view('Pages/common/header');
			$this->load->view('Pages/common/top-header');
			$this->load->view('Pages/common/left-sidebar',$titles);
			$this->load->view('Pages/change_pass');
        }else{
                redirect('/');
        }
	}

	public function change_password() {
        $update_password = $this->input->post('update_password');
        $query = $this->Login_Model->change_password($update_password);
        if($query == true){
            $status = "success";
            $this->session->set_flashdata('saved_sc','Successfully Saved.');
        }else{
            $status = "failed".$query;
        }
        $this->output->set_content_type('application/json');
        echo json_encode(array('status' => $status));
    }

    
}